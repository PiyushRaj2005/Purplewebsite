<?php

$host = 'localhost';
$username = 'root';
$password = 'root';  // Adjust if different
$database = 'ecommerce_db';
$port = 8889;  // Default MAMP MySQL port

// Create connection
$conn = new mysqli($host, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
