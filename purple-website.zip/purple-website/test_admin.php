<?php
require_once "dbconnection.php";

// Test admin credentials
$test_email = 'admin@example.com';
$test_password = 'admin123';

// Query the admin
$sql = "SELECT * FROM admins WHERE email = ?";
$stmt = mysqli_stmt_init($conn);
if (mysqli_stmt_prepare($stmt, $sql)) {
    mysqli_stmt_bind_param($stmt, "s", $test_email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $admin = mysqli_fetch_assoc($result);
    
    if ($admin) {
        echo "Admin found in database<br>";
        echo "Stored password: " . $admin['password'] . "<br>";
        
        // Direct password comparison
        if ($test_password === $admin['password']) {
            echo "Password verification successful!";
        } else {
            echo "Password verification failed!";
            echo "<br>Test password: " . $test_password;
            echo "<br>Stored password: " . $admin['password'];
        }
    } else {
        echo "No admin found with email: " . $test_email;
    }
} else {
    echo "SQL Error: " . mysqli_error($conn);
}
?>