<?php
require_once "dbconnection.php";

// Admin credentials to create
$admin_email = 'admin@example.com';
$admin_password = 'admin123';
$admin_username = 'admin';

// Hash the password
$hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

// Prepare and execute the query
$sql = "INSERT INTO admins (email, password, username) VALUES (?, ?, ?)";
$stmt = mysqli_stmt_init($conn);
if (mysqli_stmt_prepare($stmt, $sql)) {
    mysqli_stmt_bind_param($stmt, "sss", $admin_email, $hashed_password, $admin_username);
    if (mysqli_stmt_execute($stmt)) {
        echo "Admin account created successfully!<br>";
        echo "Email: " . $admin_email . "<br>";
        echo "Password: " . $admin_password . "<br>";
        echo "Username: " . $admin_username;
    } else {
        echo "Error creating admin account: " . mysqli_error($conn);
    }
} else {
    echo "SQL Error: " . mysqli_error($conn);
}
?>