<?php
// Enable error reporting for debugging (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if the user is logged in and is a seller
if (!isset($_SESSION["user"]) || $_SESSION["role"] !== 'seller') {
    header("Location: login.php");
    exit();
}

require_once "dbconnection.php"; // Include the database connection

// Initialize variables for messages
$success = "";
$error = "";

// Handle product addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $productName = trim($_POST['product_name']);
    $productPrice = floatval($_POST['product_price']);
    $productImage = $_FILES['product_image'];

    // Validate inputs
    if (empty($productName) || empty($productPrice) || $productImage['error'] !== UPLOAD_ERR_OK) {
        $error = "All fields are required and image must be uploaded.";
    } else {
        // Ensure uploads directory exists
        $upload_dir = "uploads/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true); // Use 0755 for better security
        }

        // Validate file type (allow only images)
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($productImage['type'], $allowed_types)) {
            $error = "Only JPG, PNG, and GIF files are allowed.";
        } else {
            // Generate unique filename to prevent overwriting
            $imageExtension = pathinfo($productImage['name'], PATHINFO_EXTENSION);
            $imageName = time() . '_' . uniqid() . '.' . $imageExtension;
            $targetFile = $upload_dir . $imageName;

            // Move uploaded file
            if (move_uploaded_file($productImage['tmp_name'], $targetFile)) {
                // Insert product into the database using prepared statements
                $stmt = $conn->prepare("INSERT INTO products (name, price, image, seller_id) VALUES (?, ?, ?, ?)");
                if ($stmt) {
                    $stmt->bind_param("sdsi", $productName, $productPrice, $imageName, $_SESSION["user"]);
                    if ($stmt->execute()) {
                        $success = "Product added successfully.";
                    } else {
                        $error = "Error adding product: " . $stmt->error;
                    }
                    $stmt->close();
                } else {
                    $error = "Database error: " . $conn->error;
                }
            } else {
                $error = "Failed to upload image.";
            }
        }
    }
}

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_product'])) {
    $productId = intval($_POST['product_id']);

    // Verify that the product belongs to the seller
    $stmt = $conn->prepare("SELECT image FROM products WHERE id = ? AND seller_id = ?");
    if ($stmt) {
        $stmt->bind_param("ii", $productId, $_SESSION["user"]);
        $stmt->execute();
        $stmt->bind_result($imageName);
        if ($stmt->fetch()) {
            $stmt->close();

            // Delete the product from the database
            $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("i", $productId);
                if ($stmt->execute()) {
                    // Delete the image file
                    $imagePath = $upload_dir . $imageName;
                    if (file_exists($imagePath)) {
                        unlink($imagePath);
                    }
                    $success = "Product deleted successfully.";
                } else {
                    $error = "Error deleting product: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error = "Database error: " . $conn->error;
            }
        } else {
            $error = "Product not found or you do not have permission to delete it.";
            $stmt->close();
        }
    } else {
        $error = "Database error: " . $conn->error;
    }
}

// Fetch seller's products
$sellerId = $_SESSION["user"];
$stmt = $conn->prepare("SELECT * FROM products WHERE seller_id = ?");
if ($stmt) {
    $stmt->bind_param("i", $sellerId);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $error = "Database error: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Seller Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Basic styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .topbar {
            background-color: #333;
            color: #fff;
            padding: 15px;
            text-align: center;
            position: relative;
        }
        .topbar a {
            color: #fff;
            position: absolute;
            right: 20px;
            top: 15px;
            text-decoration: none;
        }
        .dashboard-container {
            padding: 20px;
        }
        .product-list {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .product-item {
            background-color: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 200px;
        }
        .product-item img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .product-item h6 {
            margin: 10px 0 5px;
            font-size: 18px;
        }
        .product-item p {
            color: #555;
        }
        .product-item form {
            margin-top: 10px;
        }
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        form label {
            margin-top: 10px;
        }
        form input,
        form button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            box-sizing: border-box;
        }
        form button {
            background-color: #28a745;
            color: #fff;
            cursor: pointer;
        }
        form button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <!-- Topbar -->
    <div class="topbar">
        <h1>Seller Dashboard</h1>
        <a href="logout.php">Logout</a>
    </div>

    <!-- Main Content -->
    <div class="dashboard-container">
        <!-- Display Success or Error Messages -->
        <?php if (!empty($success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Add New Product Form -->
        <h2>Add New Product</h2>
        <form action="seller_dashboard.php" method="post" enctype="multipart/form-data">
            <div>
                <label for="product_name">Product Name:</label>
                <input type="text" name="product_name" id="product_name" required>
            </div>
            <div>
                <label for="product_price">Product Price:</label>
                <input type="number" step="0.01" name="product_price" id="product_price" required>
            </div>
            <div>
                <label for="product_image">Product Image:</label>
                <input type="file" name="product_image" id="product_image" accept="image/*" required>
            </div>
            <br>
            <button type="submit" name="add_product">Add Product</button>
        </form>

        <!-- Seller's Products List -->
        <h2>Your Products</h2>
        <div class="product-list">
            <?php if (isset($result) && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="product-item">
                        <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <h6><?php echo htmlspecialchars($row['name']); ?></h6>
                        <p>$<?php echo number_format($row['price'], 2); ?></p>
                        <form action="seller_dashboard.php" method="post">
                            <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                            <button type="submit" name="delete_product">Delete</button>
                        </form>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>You have not added any products yet.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>