<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$upload_dir = "uploads/";
$absolute_path = $_SERVER['DOCUMENT_ROOT'] . '/saves/purple-website/' . $upload_dir;

echo "<h2>Upload Directory Test</h2>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "Upload Path: " . $absolute_path . "<br>";
echo "Directory Exists: " . (file_exists($absolute_path) ? 'Yes' : 'No') . "<br>";
echo "Is Writable: " . (is_writable($absolute_path) ? 'Yes' : 'No') . "<br>";

if (!file_exists($absolute_path)) {
    echo "Attempting to create directory...<br>";
    if (mkdir($absolute_path, 0777, true)) {
        echo "Directory created successfully!<br>";
    } else {
        echo "Failed to create directory!<br>";
        echo "Error: " . error_get_last()['message'] . "<br>";
    }
}

// Test file creation
$test_file = $absolute_path . "test.txt";
if (file_put_contents($test_file, "Test content")) {
    echo "Test file created successfully!<br>";
    unlink($test_file); // Clean up test file
} else {
    echo "Failed to create test file!<br>";
    echo "Error: " . error_get_last()['message'] . "<br>";
}
?>